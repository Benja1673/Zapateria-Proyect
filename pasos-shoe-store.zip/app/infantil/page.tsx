import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Heart, ShoppingCart, ChevronDown, User } from "lucide-react"
import Navigation from "@/components/navigation"

export default function InfantilPage() {
  const products = [
    {
      id: 1,
      name: "Marvel",
      subtitle: "Zapatillas Capitán América Infantil",
      price: 35990,
      originalPrice: 49990,
      discount: 28,
      image: "/images/zapatilla-capitan-america.png",
      colors: ["azul", "rojo", "blanco"],
      rating: 4.8,
      reviews: 15,
      sizes: ["28", "29", "30", "31", "32"],
    },
    {
      id: 2,
      name: "Marvel",
      subtitle: "Zapatillas Spider-Man Botín Infantil",
      price: 42990,
      originalPrice: 59990,
      discount: 28,
      image: "/images/zapatilla-spiderman-botin.png",
      colors: ["negro", "rojo"],
      rating: 4.6,
      reviews: 12,
      sizes: ["26", "27", "28", "29", "30"],
    },
    {
      id: 3,
      name: "Bubble Gummers",
      subtitle: "Zapatillas Deportivas Infantil",
      price: 29990,
      originalPrice: 39990,
      discount: 25,
      image: "/images/zapatilla-bubble-gummers.png",
      colors: ["gris", "amarillo"],
      rating: 4.5,
      reviews: 8,
      sizes: ["24", "25", "26", "27", "28"],
    },
    {
      id: 4,
      name: "Marvel",
      subtitle: "Zapatillas Spider-Man Azul Infantil",
      price: 38990,
      originalPrice: 54990,
      discount: 29,
      image: "/images/zapatilla-spiderman-azul.png",
      colors: ["azul", "rojo"],
      rating: 4.7,
      reviews: 10,
      sizes: ["29", "30", "31", "32", "33"],
    },
    {
      id: 5,
      name: "Nike",
      subtitle: "Zapatillas Deportivas Azul Marino",
      price: 45990,
      originalPrice: 64990,
      discount: 29,
      image: "/images/zapatilla-azul-marino.png",
      colors: ["azul"],
      rating: 4.3,
      reviews: 6,
      sizes: ["26", "27", "28", "29", "30"],
    },
    {
      id: 6,
      name: "Adidas",
      subtitle: "Zapatillas Blancas con Detalles Neón",
      price: 52990,
      originalPrice: 74990,
      discount: 29,
      image: "/images/zapatilla-blanca-neon.png",
      colors: ["blanco", "negro", "verde"],
      rating: 4.9,
      reviews: 20,
      sizes: ["27", "28", "29", "30", "31"],
    },
    {
      id: 7,
      name: "Puma",
      subtitle: "Zapatillas Azul con Verde Neón",
      price: 41990,
      originalPrice: 59990,
      discount: 30,
      image: "/images/zapatilla-azul-verde.png",
      colors: ["azul", "verde"],
      rating: 4.4,
      reviews: 14,
      sizes: ["24", "25", "26", "27", "28"],
    },
    {
      id: 8,
      name: "Converse",
      subtitle: "Zapatillas Negras Suela Marrón",
      price: 33990,
      originalPrice: 47990,
      discount: 29,
      image: "/images/zapatilla-negra-suela-marron.png",
      colors: ["negro", "marrón"],
      rating: 4.6,
      reviews: 9,
      sizes: ["30", "31", "32", "33", "34"],
    },
    {
      id: 9,
      name: "Fila",
      subtitle: "Zapatillas Blancas Clásicas",
      price: 28990,
      originalPrice: 39990,
      discount: 27,
      image: "/images/zapatilla-blanca-clasica.png",
      colors: ["blanco"],
      rating: 4.5,
      reviews: 11,
      sizes: ["28", "29", "30", "31", "32"],
    },
    {
      id: 10,
      name: "Skechers",
      subtitle: "Zapatillas Deportivas Running",
      price: 47990,
      originalPrice: 67990,
      discount: 29,
      image: "/placeholder.svg?height=400&width=300",
      colors: ["gris", "azul"],
      rating: 4.2,
      reviews: 7,
      sizes: ["26", "27", "28", "29", "30"],
    },
  ]

  const brands = ["Marvel", "Nike", "Adidas", "Bubble Gummers", "Puma"]

  return (
    <div className="min-h-screen bg-white">
      {/* Top Banner */}
      <div className="bg-red-700 text-white text-center py-2 text-sm">
        DESPACHO GRATIS sólo Región Metropolitana por compras sobre $29.990
      </div>

      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between py-4">
            {/* Logo */}
            <Link href="/" className="text-4xl font-bold">
              PASOS
              <span className="text-red-600">.</span>
            </Link>

            {/* Search and Icons */}
            <div className="flex items-center space-x-4">
              <div className="hidden md:block">
                <input
                  type="search"
                  placeholder="Buscar zapatos..."
                  className="px-4 py-2 border border-gray-300 rounded-lg w-64"
                />
              </div>
              <div className="flex items-center space-x-2">
                <Button variant="ghost" size="icon">
                  <Heart className="h-5 w-5" />
                  <span className="sr-only">Favoritos</span>
                </Button>
                <Button variant="ghost" size="icon" className="relative">
                  <ShoppingCart className="h-5 w-5" />
                  <Badge className="absolute -top-2 -right-2 h-5 w-5 rounded-full p-0 flex items-center justify-center text-xs">
                    0
                  </Badge>
                </Button>
                <Button variant="ghost" size="icon">
                  <User className="h-5 w-5" />
                  <span className="sr-only">Mi Cuenta</span>
                </Button>
              </div>
            </div>
          </div>

          {/* Navigation */}
          <Navigation currentPage="infantil" />
        </div>
      </header>

      {/* Breadcrumb and Filters */}
      <div className="bg-gray-50 border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-end">
            <Button variant="outline" size="sm" className="bg-white">
              🔄 Ordenar por: Más relevantes
              <ChevronDown className="h-4 w-4 ml-2" />
            </Button>
          </div>
        </div>
      </div>

      {/* Products Grid */}
      <main className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
          {products.map((product) => (
            <Card key={product.id} className="group hover:shadow-lg transition-shadow">
              <CardContent className="p-0">
                <div className="relative">
                  <Image
                    src={product.image || "/placeholder.svg"}
                    alt={product.name}
                    width={300}
                    height={400}
                    className="w-full h-64 object-cover rounded-t-lg"
                  />
                  <Button variant="ghost" size="icon" className="absolute top-2 right-2 bg-white/80 hover:bg-white">
                    <Heart className="h-4 w-4" />
                  </Button>
                  <Badge className="absolute top-2 left-2 bg-blue-600 text-white text-xs">Despacho Gratis en App</Badge>
                  <div className="absolute bottom-2 left-2 bg-red-600 text-white px-2 py-1 text-xs rounded">
                    {product.discount}% {product.price.toLocaleString()}
                  </div>
                </div>
                <div className="p-3">
                  <h3 className="font-semibold text-sm text-gray-900">{product.name}</h3>
                  <p className="text-xs text-gray-600 mb-2">{product.subtitle}</p>

                  {/* Rating */}
                  <div className="flex items-center mb-2">
                    <div className="flex text-yellow-400 text-xs">
                      {"★".repeat(Math.floor(product.rating))}
                      {"☆".repeat(5 - Math.floor(product.rating))}
                    </div>
                    <span className="text-xs text-gray-500 ml-1">({product.reviews})</span>
                  </div>

                  {/* Price */}
                  <div className="mb-3">
                    <div className="text-xs text-gray-500 line-through">${product.originalPrice.toLocaleString()}</div>
                    <div className="flex items-center">
                      <span className="text-xs bg-red-100 text-red-600 px-1 rounded mr-2">{product.discount}%</span>
                      <span className="font-bold text-sm">${product.price.toLocaleString()}</span>
                    </div>
                    <Badge variant="secondary" className="text-xs mt-1">
                      CMR
                    </Badge>
                  </div>

                  {/* Colors */}
                  <div className="flex space-x-1 mb-2">
                    {product.colors.map((color, index) => (
                      <div
                        key={index}
                        className={`w-4 h-4 rounded border ${
                          color === "negro"
                            ? "bg-black"
                            : color === "azul"
                              ? "bg-blue-600"
                              : color === "rojo"
                                ? "bg-red-600"
                                : color === "rosado"
                                  ? "bg-pink-300"
                                  : color === "blanco"
                                    ? "bg-white border-gray-400"
                                    : color === "verde"
                                      ? "bg-green-600"
                                      : color === "gris"
                                        ? "bg-gray-500"
                                        : "bg-gray-300"
                        }`}
                      />
                    ))}
                  </div>

                  {/* Sizes */}
                  <div className="text-xs text-gray-600 mb-3">Tallas: {product.sizes.join(", ")}</div>

                  <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white text-xs py-2">
                    🛒 Agregar al carro
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </main>
    </div>
  )
}
