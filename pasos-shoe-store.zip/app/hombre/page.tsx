import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Heart, ShoppingCart, ChevronDown, User } from "lucide-react"
import Navigation from "@/components/navigation"

export default function HombrePage() {
  const products = [
    {
      id: 1,
      name: "Guante",
      subtitle: "Botín Dallas Cuero 35640 Hombre",
      price: 55990,
      originalPrice: 69990,
      discount: 20,
      image: "/images/zapato-botin-marron.png",
      colors: ["negro", "café"],
      rating: 5,
      reviews: 0,
    },
    {
      id: 2,
      name: "Caterpillar",
      subtitle: "Zapato Deportivo Urbano Negro",
      price: 55990,
      originalPrice: 69990,
      discount: 20,
      image: "/images/zapato-deportivo-negro.png",
      colors: ["negro", "gris"],
      rating: 4.8,
      reviews: 12,
    },
    {
      id: 3,
      name: "Panama Jack",
      subtitle: "Bota Outdoor Cuero Negro",
      price: 44990,
      originalPrice: 73990,
      discount: 39,
      image: "/images/bota-negra-outdoor.png",
      colors: ["negro"],
      rating: 4.5,
      reviews: 8,
    },
    {
      id: 4,
      name: "Florsheim",
      subtitle: "Botines Casuall Lodge Chukka Café",
      price: 104990,
      originalPrice: 149990,
      discount: 30,
      image: "/placeholder.svg?height=400&width=300",
      colors: [],
      rating: 0,
      reviews: 0,
    },
    {
      id: 5,
      name: "Guante",
      subtitle: "Botín Cuero Dortmund 35646 Hombre",
      price: 47990,
      originalPrice: 59990,
      discount: 20,
      image: "/placeholder.svg?height=400&width=300",
      colors: ["negro", "café"],
      rating: 0,
      reviews: 0,
    },
    {
      id: 6,
      name: "London Adixt",
      subtitle: "Botín de Cuero con Chiporro Aegir Café London Adixt",
      price: 44990,
      originalPrice: 73990,
      discount: 39,
      image: "/placeholder.svg?height=400&width=300",
      colors: [],
      rating: 1,
      reviews: 0,
    },
    {
      id: 7,
      name: "Véroz",
      subtitle: "Zapato Mid Cuero Hombre Véroz Milenio Mid Light - Negro",
      price: 114990,
      originalPrice: null,
      discount: null,
      image: "/placeholder.svg?height=400&width=300",
      colors: [],
      rating: 0,
      reviews: 0,
    },
    {
      id: 8,
      name: "Panama Jack",
      subtitle: "Botín Flex Foam P1003",
      price: 47990,
      originalPrice: 69990,
      discount: 20,
      image: "/placeholder.svg?height=400&width=300",
      colors: ["negro", "café"],
      rating: 0,
      reviews: 0,
    },
    {
      id: 9,
      name: "Guante",
      subtitle: "Botín Dortmund 35645 Cuero Hombre",
      price: 47990,
      originalPrice: 59990,
      discount: 20,
      image: "/placeholder.svg?height=400&width=300",
      colors: ["negro", "café"],
      rating: 0,
      reviews: 0,
    },
    {
      id: 10,
      name: "Alaniz",
      subtitle: "Botín Estilo Chelsea Hombre",
      price: 41990,
      originalPrice: 59990,
      discount: 30,
      image: "/placeholder.svg?height=400&width=300",
      colors: ["negro", "café"],
      rating: 0,
      reviews: 0,
    },
  ]

  const brands = ["Guante", "Caterpillar", "CAT", "Hush Puppies", "Panama Jack"]

  return (
    <div className="min-h-screen bg-white">
      {/* Top Banner */}
      <div className="bg-red-700 text-white text-center py-2 text-sm">
        DESPACHO GRATIS sólo Región Metropolitana por compras sobre $29.990
      </div>

      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between py-4">
            {/* Logo */}
            <Link href="/" className="flex items-center gap-2">
              <Image src="/logo.svg" alt="Pasos" width={32} height={32} />
              <span className="text-2xl font-bold">
                Pasos<span className="text-red-600">.</span>
              </span>
            </Link>

            {/* Search and Icons */}
            <div className="flex items-center space-x-4">
              <div className="hidden md:block">
                <input
                  type="search"
                  placeholder="Buscar productos..."
                  className="px-4 py-2 border border-gray-300 rounded-lg w-64"
                />
              </div>
              <div className="flex items-center space-x-2">
                <Button variant="ghost" size="icon">
                  <Heart className="h-5 w-5" />
                  <span className="sr-only">Favoritos</span>
                </Button>
                <Button variant="ghost" size="icon" className="relative">
                  <ShoppingCart className="h-5 w-5" />
                  <Badge className="absolute -top-2 -right-2 h-5 w-5 rounded-full p-0 flex items-center justify-center text-xs">
                    0
                  </Badge>
                </Button>
                <Button variant="ghost" size="icon">
                  <User className="h-5 w-5" />
                  <span className="sr-only">Mi cuenta</span>
                </Button>
              </div>
            </div>
          </div>

          {/* Navigation */}
          <Navigation currentPage="hombre" />
        </div>
      </header>

      {/* Breadcrumb and Filters */}
      <div className="bg-gray-50 border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-end">
            <Button variant="outline" size="sm" className="bg-white">
              🔄 Ordenar por: Más relevantes
              <ChevronDown className="h-4 w-4 ml-2" />
            </Button>
          </div>
        </div>
      </div>

      {/* Products Grid */}
      <main className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
          {products.map((product) => (
            <Card key={product.id} className="group hover:shadow-lg transition-shadow">
              <CardContent className="p-0">
                <div className="relative">
                  <Image
                    src={product.image || "/placeholder.svg"}
                    alt={product.name}
                    width={300}
                    height={400}
                    className="w-full h-64 object-cover rounded-t-lg"
                  />
                  <Button variant="ghost" size="icon" className="absolute top-2 right-2 bg-white/80 hover:bg-white">
                    <Heart className="h-4 w-4" />
                  </Button>
                  {product.discount && (
                    <Badge className="absolute top-2 left-2 bg-blue-600 text-white text-xs">
                      Despacho Gratis en App
                    </Badge>
                  )}
                  {product.discount && (
                    <div className="absolute bottom-2 left-2 bg-red-600 text-white px-2 py-1 text-xs rounded">
                      {product.discount}% {product.price.toLocaleString()}
                    </div>
                  )}
                </div>
                <div className="p-3">
                  <h3 className="font-semibold text-sm text-gray-900">{product.name}</h3>
                  <p className="text-xs text-gray-600 mb-2">{product.subtitle}</p>

                  {/* Rating */}
                  <div className="flex items-center mb-2">
                    <div className="flex text-yellow-400 text-xs">
                      {"★".repeat(Math.floor(product.rating))}
                      {"☆".repeat(5 - Math.floor(product.rating))}
                    </div>
                    <span className="text-xs text-gray-500 ml-1">
                      {product.reviews > 0 ? `(${product.reviews})` : "(0)"}
                    </span>
                  </div>

                  {/* Price */}
                  <div className="mb-3">
                    {product.originalPrice && (
                      <div className="text-xs text-gray-500 line-through">
                        ${product.originalPrice.toLocaleString()}
                      </div>
                    )}
                    <div className="flex items-center">
                      {product.discount && (
                        <span className="text-xs bg-red-100 text-red-600 px-1 rounded mr-2">{product.discount}%</span>
                      )}
                      <span className="font-bold text-sm">${product.price.toLocaleString()}</span>
                    </div>
                    {product.discount && product.price <= 40990 && (
                      <Badge variant="secondary" className="text-xs mt-1">
                        CMR
                      </Badge>
                    )}
                  </div>

                  {/* Colors */}
                  {product.colors.length > 0 && (
                    <div className="flex space-x-1 mb-3">
                      {product.colors.map((color, index) => (
                        <div
                          key={index}
                          className={`w-4 h-4 rounded border ${
                            color === "negro"
                              ? "bg-black"
                              : color === "café"
                                ? "bg-amber-800"
                                : color === "caramelo"
                                  ? "bg-orange-400"
                                  : "bg-gray-300"
                          }`}
                        />
                      ))}
                    </div>
                  )}

                  <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white text-xs py-2">
                    🛒 Agregar al carro
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </main>
    </div>
  )
}
