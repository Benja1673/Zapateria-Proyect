import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Heart, ShoppingCart, User } from "lucide-react"
import Navigation from "@/components/navigation"

export default function HomePage() {
  const featuredProducts = [
    {
      id: 1,
      name: "Zapatos Deportivos Hombre",
      price: 89990,
      originalPrice: 129990,
      discount: 30,
      image: "/images/zapato-deportivo-negro.png",
      category: "hombre",
      brand: "Caterpillar",
    },
    {
      id: 2,
      name: "Botas Casuales Mujer",
      price: 79990,
      originalPrice: 119990,
      discount: 35,
      image: "/placeholder.svg?height=400&width=300",
      category: "mujer",
    },
    {
      id: 3,
      name: "Zapatillas Infantiles",
      price: 49990,
      originalPrice: 69990,
      discount: 30,
      image: "/images/zapatilla-capitan-america.png",
      category: "infantil",
      brand: "Marvel",
    },
    {
      id: 4,
      name: "Botín Cuero Hombre",
      price: 99990,
      originalPrice: 149990,
      discount: 35,
      image: "/images/zapato-botin-marron.png",
      category: "hombre",
      brand: "Guante",
    },
  ]

  const shopTheLookProducts = [
    {
      id: 5,
      name: "Bota Outdoor Hombre",
      price: 119990,
      originalPrice: 159990,
      discount: 25,
      image: "/images/bota-negra-outdoor.png",
      colors: ["negro", "gris"],
      brand: "Panama Jack",
    },
    {
      id: 6,
      name: "Botas de Trabajo",
      price: 89990,
      originalPrice: 129990,
      discount: 30,
      image: "/placeholder.svg?height=400&width=300",
      colors: ["negro", "café"],
    },
    {
      id: 7,
      name: "Zapatos Casuales",
      price: 69990,
      originalPrice: 99990,
      discount: 30,
      image: "/placeholder.svg?height=400&width=300",
      colors: ["azul", "gris"],
    },
    {
      id: 8,
      name: "Zapatillas Running",
      price: 79990,
      originalPrice: 109990,
      discount: 25,
      image: "/placeholder.svg?height=400&width=300",
      colors: ["blanco", "negro"],
    },
  ]

  return (
    <div className="min-h-screen bg-white">
      {/* Top Banner */}
      <div className="bg-red-700 text-white text-center py-2 text-sm">
        DESPACHO GRATIS sólo Región Metropolitana por compras sobre $29.990
      </div>

      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between py-4">
            {/* Logo */}
            <Link href="/" className="flex items-center space-x-3">
              <Image src="/images/pasos-logo.png" alt="Pasos Logo" width={50} height={50} className="object-contain" />
              <span className="text-4xl font-bold">
                PASOS
                <span className="text-red-600">.</span>
              </span>
            </Link>

            {/* Search and Icons */}
            <div className="flex items-center space-x-4">
              <div className="hidden md:block">
                <input
                  type="search"
                  placeholder="Buscar zapatos..."
                  className="px-4 py-2 border border-gray-300 rounded-lg w-64"
                />
              </div>
              <div className="flex items-center space-x-2">
                <Button variant="ghost" size="icon">
                  <Heart className="h-5 w-5" />
                  <Badge className="absolute -top-2 -right-2 h-5 w-5 rounded-full p-0 flex items-center justify-center text-xs">
                    0
                  </Badge>
                  <span className="sr-only">Favoritos</span>
                </Button>
                <Button variant="ghost" size="icon">
                  <User className="h-5 w-5" />
                  <span className="sr-only">Mi cuenta</span>
                </Button>
                <Button variant="ghost" size="icon" className="relative">
                  <ShoppingCart className="h-5 w-5" />
                  <Badge className="absolute -top-2 -right-2 h-5 w-5 rounded-full p-0 flex items-center justify-center text-xs">
                    0
                  </Badge>
                </Button>
              </div>
            </div>
          </div>

          {/* Navigation */}
          <Navigation />
        </div>
      </header>

      {/* Hero Section */}
      <section className="bg-gradient-to-r from-gray-900 to-gray-700 text-white relative overflow-hidden">
        <div className="container mx-auto px-4 py-16">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-center">
            {/* Left Model */}
            <div className="hidden lg:block">
              <Image
                src="/images/hero-couple.png"
                alt="Pareja joven con zapatillas deportivas"
                width={400}
                height={600}
                className="rounded-lg object-cover"
              />
            </div>

            {/* Center Content */}
            <div className="text-center space-y-6">
              <h1 className="text-5xl md:text-7xl font-bold">
                ZAPATOS
                <br />Y CALZADO
              </h1>
              <div className="bg-red-600 text-white px-6 py-2 inline-block text-sm font-medium rounded">
                HASTA EL 31 DE DICIEMBRE
              </div>
              <div className="bg-red-600 text-white p-8 rounded-lg inline-block">
                <div className="text-6xl md:text-8xl font-bold">
                  50<span className="text-3xl">%</span>
                </div>
                <div className="text-lg font-medium">CON EL CUPÓN</div>
                <div className="bg-white text-red-600 px-4 py-2 rounded font-bold text-xl mt-2">PASOS50</div>
              </div>
              <Button size="lg" className="bg-white text-gray-900 hover:bg-gray-100 px-8 py-3 text-lg font-medium">
                VER TODO
              </Button>
            </div>

            {/* Right Model */}
            <div className="hidden lg:block">
              <Image
                src="/images/hero-woman-hd.png"
                alt="Mujer con zapatos casuales"
                width={400}
                height={600}
                className="rounded-lg object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Best Sellers Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">LOS MÁS VENDIDOS</h2>
            <h3 className="text-4xl font-bold text-gray-900">⚡IMPERDIBLES PASOS⚡</h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {featuredProducts.map((product) => (
              <Card key={product.id} className="group hover:shadow-lg transition-shadow">
                <CardContent className="p-0">
                  <div className="relative">
                    <Image
                      src={product.image || "/placeholder.svg"}
                      alt={product.name}
                      width={300}
                      height={400}
                      className="w-full h-80 object-cover rounded-t-lg"
                    />
                    <Button variant="ghost" size="icon" className="absolute top-4 right-4 bg-white/80 hover:bg-white">
                      <Heart className="h-4 w-4" />
                    </Button>
                    <Badge className="absolute top-4 left-4 bg-red-600">-{product.discount}%</Badge>
                  </div>
                  <div className="p-4">
                    <h4 className="font-medium text-gray-900 mb-2">{product.name}</h4>
                    <div className="flex items-center space-x-2 mb-3">
                      <span className="text-lg font-bold text-gray-900">${product.price.toLocaleString()}</span>
                      <span className="text-sm text-gray-500 line-through">
                        ${product.originalPrice.toLocaleString()}
                      </span>
                    </div>
                    <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white">🛒 Agregar al carro</Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Shop The Look Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900">SHOP THE LOOK</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {shopTheLookProducts.map((product) => (
              <Card key={product.id} className="group hover:shadow-lg transition-shadow">
                <CardContent className="p-0">
                  <div className="relative">
                    <Image
                      src={product.image || "/placeholder.svg"}
                      alt={product.name}
                      width={300}
                      height={400}
                      className="w-full h-80 object-cover rounded-t-lg"
                    />
                    <Button variant="ghost" size="icon" className="absolute top-4 right-4 bg-white/80 hover:bg-white">
                      <Heart className="h-4 w-4" />
                    </Button>
                    <div className="absolute top-4 left-4 bg-red-600 text-white px-3 py-1 text-xs font-medium rounded">
                      TODO EL SITIO {product.discount}% OFF CON EL CUPÓN PASOS{product.discount}
                    </div>
                  </div>
                  <div className="p-4">
                    <h4 className="font-medium text-gray-900 mb-2">{product.name}</h4>
                    <div className="flex items-center space-x-2 mb-3">
                      <span className="text-lg font-bold text-gray-900">${product.price.toLocaleString()}</span>
                      <span className="text-sm text-gray-500 line-through">
                        ${product.originalPrice.toLocaleString()}
                      </span>
                    </div>
                    <div className="flex space-x-1 mb-3">
                      {product.colors.map((color, index) => (
                        <div
                          key={index}
                          className={`w-6 h-6 rounded border-2 border-gray-300 ${
                            color === "negro"
                              ? "bg-black"
                              : color === "marrón" || color === "café"
                                ? "bg-amber-800"
                                : color === "azul"
                                  ? "bg-blue-600"
                                  : color === "gris"
                                    ? "bg-gray-500"
                                    : "bg-white"
                          }`}
                        />
                      ))}
                    </div>
                    <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white">🛒 Agregar al carro</Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-2xl font-bold mb-4">PASOS</h3>
              <p className="text-gray-400">Tu tienda de confianza para el mejor calzado</p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Categorías</h4>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <Link href="/hombre" className="hover:text-white">
                    Hombre
                  </Link>
                </li>
                <li>
                  <Link href="/mujer" className="hover:text-white">
                    Mujer
                  </Link>
                </li>
                <li>
                  <Link href="/infantil" className="hover:text-white">
                    Infantil
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Ayuda</h4>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <Link href="/contacto" className="hover:text-white">
                    Contacto
                  </Link>
                </li>
                <li>
                  <Link href="/envios" className="hover:text-white">
                    Envíos
                  </Link>
                </li>
                <li>
                  <Link href="/devoluciones" className="hover:text-white">
                    Devoluciones
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Síguenos</h4>
              <div className="flex space-x-4">
                <Button variant="ghost" size="icon" className="text-gray-400 hover:text-white">
                  <span className="sr-only">Facebook</span>📘
                </Button>
                <Button variant="ghost" size="icon" className="text-gray-400 hover:text-white">
                  <span className="sr-only">Instagram</span>📷
                </Button>
              </div>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 Pasos. Todos los derechos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
