import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Heart, ShoppingCart, ChevronDown, User } from "lucide-react"
import Navigation from "@/components/navigation"

export default function MujerPage() {
  const products = [
    {
      id: 1,
      name: "Bata",
      subtitle: "Zapatos Casuales Mujer Cuero",
      price: 45990,
      originalPrice: 65990,
      discount: 30,
      image: "/placeholder.svg?height=400&width=300",
      colors: ["negro", "café"],
      rating: 4.5,
      reviews: 8,
    },
    {
      id: 2,
      name: "Vizzano",
      subtitle: "Botas Altas Mujer Cuero",
      price: 89990,
      originalPrice: 119990,
      discount: 25,
      image: "/placeholder.svg?height=400&width=300",
      colors: ["negro", "marrón"],
      rating: 4.8,
      reviews: 15,
    },
    {
      id: 3,
      name: "Modare",
      subtitle: "Zapatos de Tacón Bajo Mujer",
      price: 39990,
      originalPrice: 59990,
      discount: 35,
      image: "/placeholder.svg?height=400&width=300",
      colors: ["negro", "nude"],
      rating: 4.2,
      reviews: 6,
    },
    {
      id: 4,
      name: "Piccadilly",
      subtitle: "Zapatillas Deportivas Mujer",
      price: 55990,
      originalPrice: 79990,
      discount: 30,
      image: "/placeholder.svg?height=400&width=300",
      colors: ["blanco", "rosado"],
      rating: 4.7,
      reviews: 12,
    },
    {
      id: 5,
      name: "Azaleia",
      subtitle: "Sandalias de Tacón Mujer",
      price: 42990,
      originalPrice: 62990,
      discount: 32,
      image: "/placeholder.svg?height=400&width=300",
      colors: ["negro", "dorado"],
      rating: 4.3,
      reviews: 9,
    },
    {
      id: 6,
      name: "Usaflex",
      subtitle: "Zapatos Cómodos Mujer Cuero",
      price: 67990,
      originalPrice: 89990,
      discount: 25,
      image: "/placeholder.svg?height=400&width=300",
      colors: ["negro", "azul"],
      rating: 4.6,
      reviews: 18,
    },
    {
      id: 7,
      name: "Moleca",
      subtitle: "Ballerinas Mujer Cuero",
      price: 35990,
      originalPrice: 49990,
      discount: 28,
      image: "/placeholder.svg?height=400&width=300",
      colors: ["negro", "beige"],
      rating: 4.1,
      reviews: 7,
    },
    {
      id: 8,
      name: "Comfortflex",
      subtitle: "Botines Mujer Cuero",
      price: 79990,
      originalPrice: 109990,
      discount: 27,
      image: "/placeholder.svg?height=400&width=300",
      colors: ["café", "negro"],
      rating: 4.4,
      reviews: 11,
    },
    {
      id: 9,
      name: "Ramarim",
      subtitle: "Zapatos Formales Mujer",
      price: 52990,
      originalPrice: 74990,
      discount: 29,
      image: "/placeholder.svg?height=400&width=300",
      colors: ["negro", "vino"],
      rating: 4.5,
      reviews: 13,
    },
    {
      id: 10,
      name: "Beira Rio",
      subtitle: "Zapatillas Urbanas Mujer",
      price: 38990,
      originalPrice: 54990,
      discount: 29,
      image: "/placeholder.svg?height=400&width=300",
      colors: ["blanco", "gris"],
      rating: 4.2,
      reviews: 5,
    },
  ]

  const brands = ["Bata", "Vizzano", "Modare", "Piccadilly", "Azaleia"]

  return (
    <div className="min-h-screen bg-white">
      {/* Top Banner */}
      <div className="bg-red-700 text-white text-center py-2 text-sm">
        DESPACHO GRATIS sólo Región Metropolitana por compras sobre $29.990
      </div>

      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between py-4">
            {/* Logo */}
            <Link href="/" className="text-4xl font-bold">
              PASOS
              <span className="text-red-600">.</span>
            </Link>

            {/* Search and Icons */}
            <div className="flex items-center space-x-4">
              <div className="hidden md:block">
                <input
                  type="search"
                  placeholder="Buscar zapatos..."
                  className="px-4 py-2 border border-gray-300 rounded-lg w-64"
                />
              </div>
              <div className="flex items-center space-x-2">
                <Button variant="ghost" size="icon">
                  <Heart className="h-5 w-5" />
                  <span className="sr-only">Favoritos</span>
                </Button>
                <Button variant="ghost" size="icon" className="relative">
                  <ShoppingCart className="h-5 w-5" />
                  <Badge className="absolute -top-2 -right-2 h-5 w-5 rounded-full p-0 flex items-center justify-center text-xs">
                    0
                  </Badge>
                </Button>
                <Button variant="ghost" size="icon">
                  <User className="h-5 w-5" />
                  <span className="sr-only">Mi cuenta</span>
                </Button>
              </div>
            </div>
          </div>

          {/* Navigation */}
          <Navigation currentPage="mujer" />
        </div>
      </header>

      {/* Breadcrumb and Filters */}
      <div className="bg-gray-50 border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-end">
            <Button variant="outline" size="sm" className="bg-white">
              🔄 Ordenar por: Más relevantes
              <ChevronDown className="h-4 w-4 ml-2" />
            </Button>
          </div>
        </div>
      </div>

      {/* Products Grid */}
      <main className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
          {products.map((product) => (
            <Card key={product.id} className="group hover:shadow-lg transition-shadow">
              <CardContent className="p-0">
                <div className="relative">
                  <Image
                    src={product.image || "/placeholder.svg"}
                    alt={product.name}
                    width={300}
                    height={400}
                    className="w-full h-64 object-cover rounded-t-lg"
                  />
                  <Button variant="ghost" size="icon" className="absolute top-2 right-2 bg-white/80 hover:bg-white">
                    <Heart className="h-4 w-4" />
                  </Button>
                  {product.discount && (
                    <Badge className="absolute top-2 left-2 bg-blue-600 text-white text-xs">
                      Despacho Gratis en App
                    </Badge>
                  )}
                  {product.discount && (
                    <div className="absolute bottom-2 left-2 bg-red-600 text-white px-2 py-1 text-xs rounded">
                      {product.discount}% {product.price.toLocaleString()}
                    </div>
                  )}
                </div>
                <div className="p-3">
                  <h3 className="font-semibold text-sm text-gray-900">{product.name}</h3>
                  <p className="text-xs text-gray-600 mb-2">{product.subtitle}</p>

                  {/* Rating */}
                  <div className="flex items-center mb-2">
                    <div className="flex text-yellow-400 text-xs">
                      {"★".repeat(Math.floor(product.rating))}
                      {"☆".repeat(5 - Math.floor(product.rating))}
                    </div>
                    <span className="text-xs text-gray-500 ml-1">({product.reviews})</span>
                  </div>

                  {/* Price */}
                  <div className="mb-3">
                    <div className="text-xs text-gray-500 line-through">${product.originalPrice.toLocaleString()}</div>
                    <div className="flex items-center">
                      <span className="text-xs bg-red-100 text-red-600 px-1 rounded mr-2">{product.discount}%</span>
                      <span className="font-bold text-sm">${product.price.toLocaleString()}</span>
                    </div>
                    {product.price <= 40990 && (
                      <Badge variant="secondary" className="text-xs mt-1">
                        CMR
                      </Badge>
                    )}
                  </div>

                  {/* Colors */}
                  <div className="flex space-x-1 mb-3">
                    {product.colors.map((color, index) => (
                      <div
                        key={index}
                        className={`w-4 h-4 rounded border ${
                          color === "negro"
                            ? "bg-black"
                            : color === "café" || color === "marrón"
                              ? "bg-amber-800"
                              : color === "nude" || color === "beige"
                                ? "bg-amber-200"
                                : color === "blanco"
                                  ? "bg-white border-gray-400"
                                  : color === "rosado"
                                    ? "bg-pink-300"
                                    : color === "dorado"
                                      ? "bg-yellow-400"
                                      : color === "azul"
                                        ? "bg-blue-600"
                                        : color === "vino"
                                          ? "bg-red-800"
                                          : color === "gris"
                                            ? "bg-gray-500"
                                            : "bg-gray-300"
                        }`}
                      />
                    ))}
                  </div>

                  <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white text-xs py-2">
                    🛒 Agregar al carro
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </main>
    </div>
  )
}
